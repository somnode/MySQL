
ERROR=0

CDATE=`date '+%y%m%d'`
BENCHMARK=copytar

if [ -z "$1" ]; then
	echo "./test [Util(%)] [Op Name]"
else
	sleep 5
	sg_sat_read_gplog -d -c 1 -L 98h /dev/sda > /home/kyuhwa/바탕화면/ssdstat_${1}_${2}_start.bin
	sleep 1
	sg_sat_read_gplog -d -c 1 -L 98h /dev/sda > /home/kyuhwa/바탕화면/ssdstat_${1}_${2}_start.bin
	sg_sat_read_gplog -d -c 1 -L 98h /dev/sda > /home/kyuhwa/바탕화면/ssdstat_${1}_${2}_start.bin
	./tpcc_start -h localhost -d tpcc10 -u root -p "" -w 40 -c 16 -r 10 -l 60 > /home/kyuhwa/바탕화면/mysqlstat_${1}_${2}.txt
	sg_sat_read_gplog -d -c 1 -L 98h /dev/sda > /home/kyuhwa/바탕화면/ssdstat_${1}_${2}_end.bin
	sleep 1
	sg_sat_read_gplog -d -c 1 -L 98h /dev/sda > /home/kyuhwa/바탕화면/ssdstat_${1}_${2}_end.bin
	sg_sat_read_gplog -d -c 1 -L 98h /dev/sda > /home/kyuhwa/바탕화면/ssdstat_${1}_${2}_end.bin
	chown kyuhwa /home/kyuhwa/바탕화면/ssdstat_${1}_${2}_start.bin
	chgrp kyuhwa /home/kyuhwa/바탕화면/ssdstat_${1}_${2}_start.bin
	chown kyuhwa /home/kyuhwa/바탕화면/ssdstat_${1}_${2}_end.bin
	chgrp kyuhwa /home/kyuhwa/바탕화면/ssdstat_${1}_${2}_end.bin
fi
