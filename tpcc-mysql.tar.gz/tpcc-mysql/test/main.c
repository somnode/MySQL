#include <stdio.h>
#include <mysql.h>

void main()
{
	MYSQL* resp;
	resp = mysql_real_connect(0, "localhost", "root", "root", "tpcc10", 3306, NULL, 0);
}
