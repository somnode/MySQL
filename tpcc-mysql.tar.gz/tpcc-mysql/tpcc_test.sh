# real utilization 49%

ERROR=0

CDATE=`date '+%y%m%d'`
BENCHMARK=copytar

if [ -z "$1" ]; then
	echo "./test [Util(%)] [Op Name]"
else
	echo 3 > /proc/sys/vm/drop_caches
	sleep 5
	sg_sat_read_gplog -d -c 1 -L 98h /dev/sdd > /home/kyuhwa/바탕화면/ssdstat_tpcc_${1}_${2}_start.bin
	sleep 1
	sg_sat_read_gplog -d -c 1 -L 98h /dev/sdd > /home/kyuhwa/바탕화면/ssdstat_tpcc_${1}_${2}_start.bin
	sg_sat_read_gplog -d -c 1 -L 98h /dev/sdd > /home/kyuhwa/바탕화면/ssdstat_tpcc_${1}_${2}_start.bin
	echo "FILEBENCH START"
	./tpcc_start -h localhost -d tpcc10 -u root -p "" -w ${2} -c 128 -r 180 -l ${3}
	echo "FILEBENCH END"
	sg_sat_read_gplog -d -c 1 -L 98h /dev/sdd > /home/kyuhwa/바탕화면/ssdstat_tpcc_${1}_${2}_end.bin
	sleep 1
	sg_sat_read_gplog -d -c 1 -L 98h /dev/sdd > /home/kyuhwa/바탕화면/ssdstat_tpcc_${1}_${2}_end.bin
	sg_sat_read_gplog -d -c 1 -L 98h /dev/sdd > /home/kyuhwa/바탕화면/ssdstat_tpcc_${1}_${2}_end.bin

	chown kyuhwa /home/kyuhwa/바탕화면/ssdstat_tpcc_${1}_${2}_start.bin
	chgrp kyuhwa /home/kyuhwa/바탕화면/ssdstat_tpcc_${1}_${2}_start.bin
	chown kyuhwa /home/kyuhwa/바탕화면/ssdstat_tpcc_${1}_${2}_end.bin
	chgrp kyuhwa /home/kyuhwa/바탕화면/ssdstat_tpcc_${1}_${2}_end.bin
fi
